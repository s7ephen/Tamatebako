/*
 * fm-unipack.c v0.1
 * [ nemo 2005 ]
 * 
 *           ;--,
 *  .________|   `,___,_.._____,..
 *  |    .___________/    |___,'
 *  ;    |   |     \/     ;
 *  |    '--------,       |--------+
 *  ;    ,_______/\  /|   |____,-'
 *  |    |   |   | \/ ;   / enace...
 *  :    |   |___|    | _;(-
 *  |____| eline.,..  |/
 *
 *
 * [*] Used for manipulating universal
 *     mach-o binaries.
 *
 * -l : list contents of universal binary
 * -p : create a universal binary, from 
 *      several mach-o files.
 * -u : unpack a universal binary into 
 *      the current directory.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <mach-o/fat.h>
#include <mach-o/loader.h>

#define MAC_MAGIC	0xfeedface
#define UNI_MAGIC	0xcafebabe
#define BSIZE		25
#define MASK		0x1000

char *filename=NULL;
char **files;

enum emode {
	UNPACK,
	PACK,	
	LIST
} mode;

void 	unpack(void)
{
	struct fat_header f_header;
        struct fat_arch   f_arch;
        FILE *ip,*op;
	char ofilename[20],c;
	unsigned long n;
	off_t	tmpoff;

	if(!filename) {
		printf("error: you must provide a filename.\n");
		exit(1);
	
	}

        if(!(ip = fopen(filename,"r"))) {
                printf("error: could not open file.\n");
                exit(1);
        }
		
	
        if(fread(&f_header, 1, sizeof(f_header),ip) != sizeof(f_header)) {
                printf("error: could not read fro the file.\n");
                exit(1);
        }

        if(f_header.magic != UNI_MAGIC) {
                printf("error: not a fat - universal binary.\n");
                exit(1);
        }


	while(f_header.nfat_arch-- && (fread(&f_arch, 1,sizeof(f_arch),ip)==sizeof(f_arch))){
		tmpoff = ftell(ip);

		if(fseek(ip,f_arch.offset,SEEK_SET) == -1) {
			printf("error: fseek failed.\n");
			exit(1);
		}
		
		snprintf(ofilename,BSIZE,"%s.fm%d",filename,f_arch.cputype);		

		if(!(op = fopen(ofilename,"w"))) {
			printf("error: could not open file.\n");
			exit(1);
		}
		
		for(n = 0; n <= f_arch.size ; n++) {
			fread (&c,1,1,ip);
			fwrite(&c,1,1,op);
		}
			
		fclose(op);

		if(fseek(ip,tmpoff,SEEK_SET) == -1) {
			printf("error: fseek failed.\n");
			exit(1);
		}
		
		chmod(ofilename,0700);
	}

	fclose(ip);	
}

void	list(void)
{
        struct fat_header f_header;
        struct fat_arch   f_arch;
	FILE *fp;

	if(!filename) {
		printf("error: you must provide a filename.\n");
		exit(1);
	}	

	if(!(fp = fopen(filename,"r"))) {
		printf("error: could not open file.\n");
		exit(1);
	}

	if(fread(&f_header, 1, sizeof(f_header),fp) != sizeof(f_header)) {
		printf("error: could not read fro the file.\n");	
		exit(1);
	}
		
	if(f_header.magic != UNI_MAGIC) {
		printf("error: not a fat - universal binary.\n");
		exit(1);
	}		
	
	printf("[+] fat universal binary found. - (0x%x)\n\n",UNI_MAGIC);
	printf("no. of files within: (%d)\n\n",f_header.nfat_arch);
	
	while(f_header.nfat_arch-- && (fread(&f_arch, 1, sizeof(f_arch),fp)==sizeof(f_arch))) {
		printf("cputype      : 0x%x\n",f_arch.cputype);
		printf("cpu substype : 0x%x\n",f_arch.cpusubtype);
		printf("offset       : 0x%x\n",f_arch.offset);
		printf("size         : 0x%x\n",f_arch.size);
		printf("align        : 0x%x\n\n",f_arch.align);
	}
	
	fclose(fp);
}

void appndfile(FILE *of,char *ifname)
{

	char zero = '\x00';
	FILE *ip;
	char buf[BSIZE];	
	unsigned int size,offset,oldoff;
	
	if(!(ip = fopen(ifname,"r"))) {
		printf("error: cannot find specified file.\n",ifname);
		exit(1);
	}

	oldoff = offset = ftell(of);
	offset = (offset/MASK+1)*MASK;
	
	while(oldoff < offset) {	// alignment
		fwrite(&zero,1,1,of);
		oldoff++;
	}

	while(size = fread(buf,1,BSIZE,ip)) {
		if(fwrite(buf,1,size,of) != size) {
			printf("error: cannot write to file.\n");
			exit(1);
		}
	}

	fclose(ip);
}


void	pack(void)
{
	FILE	*ip,*op;
	struct fat_header f_header;
	struct fat_arch	  f_arch;
	struct stat sb;
	struct mach_header m_header;
	unsigned long	offset,old_off,retrn;
	
	char **next;
	
	if(!filename) {
		printf("error: You must provide an output filename.\n");
		exit(1);
	}
	
	if(!(op = fopen(filename,"w"))) {
		printf("error: Could not open output file.\n");
		exit(1);
	}
	
	f_header.magic = UNI_MAGIC;	
	f_header.nfat_arch = 0;
	
	next = files;
	
	while(*(next++))
		++f_header.nfat_arch;

	offset = old_off = (sizeof(f_arch) * f_header.nfat_arch) + sizeof(f_header);	

	old_off = offset = (offset/MASK+1)*MASK;

	fwrite(&f_header ,sizeof(f_header), 1, op);	// write header number.
	
	next = files;
	
	do {	
		if(!(ip = fopen(*next,"r"))) {
			printf("error: cannot find specified file.\n",*next);
			exit(1);
		}
	
		if((retrn = fread(&m_header,1,sizeof(struct mach_header),ip))
					< sizeof(struct mach_header)) {
			printf("error: cannot read from file.\n");
			exit(1);
				
		}
	
		if(m_header.magic != MAC_MAGIC) {
			printf("error: invalid mach-o file.\n");
			exit(1);
		}
	
		if(stat(*next,&sb) == -1) {
			printf("error: couldn't stat file.\n");
			exit(1);
		}

		f_arch.cputype    = m_header.cputype;
		f_arch.cpusubtype = m_header.cpusubtype;
		f_arch.offset     = offset;
		f_arch.size       = sb.st_size;	
		f_arch.align      = 0xd;

		offset += sb.st_size;		// Get new offset.
		offset = (offset/MASK+1)*MASK;
		
		if(fwrite(&f_arch,1, sizeof(f_arch), op) != sizeof(f_arch)) {
			printf("error: could not write to file.\n");
			exit(1);
		}

		fclose(ip);		
	} while(*(++next));

	next = files;
	
	do {
		appndfile(op,*next);
	} while(*(++next));
			
	
	fclose(op);
	chmod(filename,0700);
}

void usage(char *progname)
{
	printf("-[ fm-unipack ]-\n");
	printf("by nemo 2005....\n\n");
	printf("usage:\n");
	printf("\t%s [-upl] file1 file2 ... <output filename>\n\n",
		progname);
	printf("\t-l :: List the contents of a Universal binary.\n");
	printf("\t-u :: Unpack Universal binary (OSX).\n");
	printf("\t-p :: Create a new Universal binary (OSX).\n\n");
	exit(1);

}

int parseargs(int ac,char **av)
{
	unsigned short n=0;	
	char *eq;

	if(!av[1])
		return 0;

	if(!strcmp(av[1],"-u")) {
		mode = UNPACK;
	} else if(!strcmp(av[1],"-p")) {
		mode = PACK;	
	} else if(!strcmp(av[1],"-l")) {
		mode = LIST;
	} else {
		return 0;
	}
		
	av++;	

	if(!(filename = av[ac - 2])) 
		return 0;

	av[ac-2] = 0x0;	

	if(!*av) 
		return 1;

	files = ++av;

	return 1;
}

int main(int ac, char **av)
{
	if(!parseargs(ac,av)) 
		usage(*av);
	
	if(mode == PACK) 
		pack();
	else if(mode == UNPACK)	
		unpack();
	else
		list();
	
	return 0;
}
